package cn.edu.aynu.rjxy.zsqd.service;

import java.sql.SQLException;
import cn.edu.aynu.rjxy.zsqd.dao.UserDao;
import cn.edu.aynu.rjxy.zsqd.dao.UserDaoImpl;
import cn.edu.aynu.rjxy.zsqd.domain.User;
import cn.edu.aynu.rjxy.zsqd.service.exception.UserException;

public class UserServiceImpl implements UserService {
	private UserDao userDao = new UserDaoImpl();// 添加依赖

	/**
	 * 登录验证
	 * 
	 * @throws SQLException
	 */

	public User login(String username, String password) throws UserException {
		try {
			User _user = userDao.findByUsername(username);
			if (_user == null) {
				throw new UserException("用户名或密码错误");
			}
			if (!password.trim().equals(_user.getPassword())) {
				throw new UserException("用户名或密码错误");
			}
			return _user;
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}

	public void regist(User user) throws UserException {
		try {
			/*
			 * 1.判断用户名是否已经被注册 2.如果已经被注册了，返回错误信息
			 * 3.如果查询数据库的返回值为null,说明改用户名没有人注册，通过dao进行注册
			 */
			User _user = userDao.findByUsername(user.getUsername());
			if (_user != null) {
				throw new UserException("用户名已经被注册！");
			}
			Integer id = userDao.addUser(user);
			if (id != 1) {
				throw new UserException("注册失败，请重新注册！");
			}
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}

	}

	public Integer improve(User user) {
		/*
		 * 1.通过userDao将用户的详细信息添加到数据库中
		 */
		try {
			return userDao.improveInformation(user);
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * 判断用户是否已经注册
	 */
	public boolean findUsername(String username) throws UserException {
		try {

			if (!userDao.isExit(username)) {// 表示用户名已经存在
				// throw new UserException("该用户名已经被注册！");
				return false;
			}
			return true;
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * 判断公司是否存在
	 */
	public boolean findCid(String cid) throws UserException {
		try {
			if (userDao.isExitCid(cid)) {
				return true;// 表示公司存在
			} else {
				throw new UserException("该公司不存在！");
			}
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}

	public void updatePassword(String username, String password)
			throws UserException {
		/*
		 * 1.通过userDao将数据提交到数据库
		 */
		try {
			User _user = userDao.findByUsername(username);
			userDao.updatePassword(username, password);
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}

	}

}
