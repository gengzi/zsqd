package cn.edu.aynu.rjxy.zsqd.service;


import cn.edu.aynu.rjxy.zsqd.domain.User;
import cn.edu.aynu.rjxy.zsqd.service.exception.UserException;



public interface UserService {

	User login(String username, String password)throws UserException;
    //用户注册服务
	void regist(User user) throws UserException;
	//用户信息完善服务
	Integer improve(User user);
	
//	void updatePassword(String username,String password, String repassword)throws UserException;
	void updatePassword(String username,String password)throws UserException;
	boolean findUsername(String username)throws UserException;
	boolean findCid(String cid) throws UserException;



}
