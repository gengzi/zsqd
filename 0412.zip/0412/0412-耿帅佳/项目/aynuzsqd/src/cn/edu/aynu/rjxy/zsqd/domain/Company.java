package cn.edu.aynu.rjxy.zsqd.domain;

import java.util.Arrays;

public class Company {
	private String cid;//公司编号
	private String cname;//公司名称
	private String[] caddress;//公司地址1
	private String[] caddressa;//公司地址2
	private String[] caddressb;//公司地址3
	public String getCid() {
		return cid;
	}
	public void setCid(String cid) {
		this.cid = cid;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String[] getCaddress() {
		return caddress;
	}
	public void setCaddress(String[] caddress) {
		this.caddress = caddress;
	}
	public String[] getCaddressa() {
		return caddressa;
	}
	public void setCaddressa(String[] caddressa) {
		this.caddressa = caddressa;
	}
	public String[] getCaddressb() {
		return caddressb;
	}
	public void setCaddressb(String[] caddressb) {
		this.caddressb = caddressb;
	}
	@Override
	public String toString() {
		return "Company [cid=" + cid + ", cname=" + cname + ", caddress="
				+ Arrays.toString(caddress) + ", caddressa="
				+ Arrays.toString(caddressa) + ", caddressb="
				+ Arrays.toString(caddressb) + "]";
	}
	
}
