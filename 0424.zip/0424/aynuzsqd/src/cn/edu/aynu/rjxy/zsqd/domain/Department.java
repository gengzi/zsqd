package cn.edu.aynu.rjxy.zsqd.domain;

/**
 * 部门表
 * 
 * @author 子
 * 
 */
public class Department {

	private String did; // 部门表
	private String dname; // 部门名
	private String cid; // 公司的标识字段 cid
	public String getDid() {
		return did;
	}
	public void setDid(String did) {
		this.did = did;
	}
	public String getDname() {
		return dname;
	}
	public void setDname(String dname) {
		this.dname = dname;
	}
	public String getCid() {
		return cid;
	}
	public void setCid(String cid) {
		this.cid = cid;
	}
	
	
	

}
