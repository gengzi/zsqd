package cn.edu.aynu.rjxy.zsqd.service;

import cn.edu.aynu.rjxy.zsqd.domain.Company;
import cn.edu.aynu.rjxy.zsqd.domain.Signin;


public interface SignService {
    //插入签到信息
	boolean insertSign(Signin signin);
    //添加公司信息
	void addCompany(Company company);

}
