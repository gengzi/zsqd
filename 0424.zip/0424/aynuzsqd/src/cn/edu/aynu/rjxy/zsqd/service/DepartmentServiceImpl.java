package cn.edu.aynu.rjxy.zsqd.service;

public class DepartmentServiceImpl implements DepartmentService {

}
