package cn.edu.aynu.rjxy.zsqd.service;

import java.util.List;

import cn.edu.aynu.rjxy.zsqd.domain.Company;

public interface CompanyService {
    //将公司gps插入到数据库
	void insertCompanyGps(Company company);

	void initCompanyInfo(Company company);

	Company findByCId(String cid);

	List<Company> getCaddress(String cid);

	void saveAPStime(Company company);

}
