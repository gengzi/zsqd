package cn.edu.aynu.rjxy.zsqd.service;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import cn.edu.aynu.rjxy.zsqd.domain.PageBean;
import cn.edu.aynu.rjxy.zsqd.domain.Signin;
import cn.edu.aynu.rjxy.zsqd.domain.User;

public interface PageService {

	public PageBean getPageBean(int pageCode, int pageSize) throws Exception;

	/**
	 * 签到信息的分页查询
	 * 
	 * @param pageCode
	 * @param pageSize
	 * @param uname
	 * @param stime
	 * @param begintime
	 * @param endtime
	 * @return
	 * @throws Exception
	 */
	public PageBean getPageBean(int pageCode, int pageSize, String uname,
			String stime, String begintime, String endtime) throws Exception;

	/**
	 * 查找所有的签到信息
	 * 
	 * @return
	 * @throws Exception
	 */
	public List<Signin> findAll() throws Exception;

	/**
	 * 查询员工信息的分页显示
	 * 
	 * @param pageCode
	 * @param pageSize
	 * @param uname
	 * @param username
	 * @return
	 * @throws Exception
	 */
	PageBean getPageBean(int pageCode, int pageSize, String uname,
			String username, String cid) throws Exception;

	/**
	 * 查找所有的员工信息
	 * 
	 * @return
	 * @throws Exception
	 */
	public List<User> findAllStaff() throws Exception;

	public PageBean getPageBeanDepartment(int parseInt, int parseInt2,
			String cid) throws Exception;

	public PageBean getPageBeanCompany(int parseInt, int parseInt2,
			Map<String, Object> map) throws Exception;

}
