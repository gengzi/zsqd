package cn.edu.aynu.rjxy.zsqd.dao;

import java.sql.SQLException;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;


import cn.edu.aynu.rjxy.zsqd.domain.Company;
import cn.itcast.jdbc.JdbcUtils;

public interface CompanyDao {

	/**将公司gps插入数据库
	 * @param company
	 * @throws SQLException
	 */
	void insertCompanyGps(Company company) throws SQLException;

	/** 注册时，初始化公司信息
	 * @param company
	 * @throws SQLException 
	 */
	void initCompanyInfo(Company company) throws SQLException;

	/**  根据cid 查询
	 * @param cid
	 */
	Company findByCId(String cid);

	/** 查询公司信息
	 * @param cid
	 * @return
	 */
	List<Company> findCaddressByCId(String cid);

	void insertAPStimeById(Company company);


}
