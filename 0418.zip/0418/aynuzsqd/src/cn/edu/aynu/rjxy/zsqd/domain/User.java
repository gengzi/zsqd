package cn.edu.aynu.rjxy.zsqd.domain;

import java.util.Date;

public class User {
	private String uid;//用户id
	private String username;//用户账号
	private String password;//用户密码
	private String uname;//用户姓名
	private String gender;//用户性别
	private String cid;//用户所属公司编号
	private Boolean isadmin;//用户身份
	public String getUid() {
		return uid;
	}
	public void setUid(String uid) {
		this.uid = uid;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getCid() {
		return cid;
	}
	public void setCid(String cid) {
		this.cid = cid;
	}
	public Boolean getIsadmin() {
		return isadmin;
	}
	public void setIsadmin(Boolean isadmin) {
		this.isadmin = isadmin;
	}
	@Override
	public String toString() {
		return "User [uid=" + uid + ", username=" + username + ", password="
				+ password + ", uname=" + uname + ", gender=" + gender
				+ ", cid=" + cid + ", isadmin=" + isadmin + "]";
	}
	
	
}
