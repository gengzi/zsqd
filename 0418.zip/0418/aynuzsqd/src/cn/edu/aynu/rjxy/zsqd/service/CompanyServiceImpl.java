package cn.edu.aynu.rjxy.zsqd.service;

import java.sql.SQLException;

import cn.edu.aynu.rjxy.zsqd.dao.CompanyDao;
import cn.edu.aynu.rjxy.zsqd.dao.CompanyDaoImpl;
import cn.edu.aynu.rjxy.zsqd.domain.Company;

public class CompanyServiceImpl implements CompanyService {
	private CompanyDao companyDao = new CompanyDaoImpl();

	@Override
	public void insertCompanyGps(Company company) {
		try {
			companyDao.insertCompanyGps(company);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void initCompanyInfo(Company company) {
		try {
			companyDao.initCompanyInfo(company);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}

	@Override
	public Company findByCId(String cid) {
	  return  companyDao.findByCId(cid);
		
	}

}
