package cn.edu.aynu.rjxy.zsqd.dao;

import java.sql.SQLException;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;

import cn.edu.aynu.rjxy.zsqd.domain.Company;
import cn.itcast.jdbc.JdbcUtils;

public class CompanyDaoImpl implements CompanyDao {
	private QueryRunner qr = new QueryRunner(JdbcUtils.getDataSource());

	@Override
	public void insertCompanyGps(Company company) throws SQLException {
		String sql = "insert into t_company(addressgps1,addressgps2,addressgps3,addressgps4,addressgps5,cid,cname,caddress,id) values(?,?,?,?,?,?,?,?,?)";
		qr.update(sql, company.getAddressgps1(), company.getAddressgps2(),
				company.getAddressgps3(), company.getAddressgps4(),
				company.getAddressgps5(), company.getCid(),company.getCname(),company.getCaddress(),company.getId());

	}

	public void initCompanyInfo(Company company) throws SQLException {

		String sql = "insert into t_company(id,cid,cname) values(?,?,?)";
		qr.update(sql, company.getId(),company.getCid(),company.getCname());

	}

	@Override
	public Company findByCId(String cid){
		String  sql = "select * from t_company where cid = ?";
		try {
			return qr.query(sql, new BeanHandler<Company>(Company.class), cid);
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}

}
