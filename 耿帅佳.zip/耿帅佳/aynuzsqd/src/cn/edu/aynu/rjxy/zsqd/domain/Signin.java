package cn.edu.aynu.rjxy.zsqd.domain;

public class Signin {
	private String sid;//签到编号
	private String uname;//员工姓名
	private User user;//签到到员工
	private Company company;//签到的公司
	private String stime;//员工签到时间
	private String saddress;//员工签到的地点
	private String saddressgps;//签到的gps
	private boolean isauto;//是否为自动签到
	private boolean issuccess;//签到是否成功
	
	
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getSid() {
		return sid;
	}
	public void setSid(String sid) {
		this.sid = sid;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public Company getCompany() {
		return company;
	}
	public void setCompany(Company company) {
		this.company = company;
	}
	public String getStime() {
		return stime;
	}
	public void setStime(String stime) {
		this.stime = stime;
	}
	public String getSaddress() {
		return saddress;
	}
	public void setSaddress(String saddress) {
		this.saddress = saddress;
	}
	public String getSaddressgps() {
		return saddressgps;
	}
	public void setSaddressgps(String saddressgps) {
		this.saddressgps = saddressgps;
	}

	public boolean isIsauto() {
		return isauto;
	}
	public void setIsauto(boolean isauto) {
		this.isauto = isauto;
	}
	public boolean isIssuccess() {
		return issuccess;
	}
	public void setIssuccess(boolean issuccess) {
		this.issuccess = issuccess;
	}
}
