package cn.edu.aynu.rjxy.zsqd.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;
import org.apache.commons.lang3.StringUtils;

import cn.edu.aynu.rjxy.zsqd.domain.Signin;
import cn.itcast.jdbc.JdbcUtils;

/**
 * 处理关于分页显示 在数据库中的操作
 * 
 * @author 子
 * 
 */
public class PageDaoImpl implements PageDao {
	// 注入数据源
	private QueryRunner queryRunner = new QueryRunner(JdbcUtils.getDataSource());

	// 得到总记录数
	public int getPageTotalSignin() throws SQLException {
		String sql = "select count(*) from t_signin"; // 拿到这个表的总行数
		// ScalarHandler 用于获取结果集中第一行某列的数据并转换成 T 表示的实际对象。
		// ScalarHandler 的参数为空或null时，返回第一行第一列的数据
		Long total = (Long) queryRunner.query(sql, new ScalarHandler());
		return total.intValue();
	}

	public List getListSignin(int recoderStartIndex, int pagesize)
			throws SQLException {
		String sql = "select * from t_signin where 1=1  limit ?,?";
		List rows = queryRunner.query(sql, new BeanListHandler<Signin>(
				Signin.class), recoderStartIndex, pagesize);
		return rows;
	}

	@Override
	public List getListSignin(int recoderStartIndex, int pageSize,
			String uname, String stime, String begintime, String endtime)
			throws SQLException {

		StringBuilder builder = new StringBuilder();
		List<Object> list = new ArrayList<Object>();

		String sql = "select * from t_signin  where 1 = 1"; // 拿到这个表的总行数
		builder.append(sql);
		// 拼装sql 语句 uname,stime,begintime,endtime
		if (StringUtils.isNotBlank(uname)) {
			builder.append(" and uname like ?");
			list.add("%" + uname + "%");
		} else if (StringUtils.isNotBlank(stime)) {
			builder.append(" and stime like ?");
			list.add(stime + "%");
		} else if (StringUtils.isNotBlank(begintime)
				&& StringUtils.isNotBlank(endtime)) {
			builder.append(" and stime  between  ? and  ? ");
			list.add(begintime);
			list.add(endtime);
		}
		builder.append(" limit ? , ? ");
		list.add(recoderStartIndex);
		list.add(pageSize);

		String sqlFind = builder.toString();
		Object[] array = list.toArray();

		List rows = queryRunner.query(sqlFind, new BeanListHandler<Signin>(
				Signin.class), array);
		return rows;
	}

	@Override
	public int getPageTotalSignin(String uname, String stime, String begintime,
			String endtime) throws SQLException {

		StringBuilder builder = new StringBuilder();
		List<Object> list = new ArrayList<Object>();

		String sql = "select count(*) from t_signin  where 1 = 1"; // 拿到这个表的总行数
		builder.append(sql);
		// 拼装sql 语句 uname,stime,begintime,endtime
		if (StringUtils.isNotBlank(uname)) {
			builder.append(" and uname like ?");
			list.add("%" + uname + "%");
		} else if (StringUtils.isNotBlank(stime)) {
			builder.append(" and stime like ?");
			list.add(stime + "%");
		} else if (StringUtils.isNotBlank(begintime)
				&& StringUtils.isNotBlank(endtime)) {
			builder.append(" and stime  between  ? and  ? ");
			list.add(begintime);
			list.add(endtime);
		}
		String sqlFind = builder.toString();
		Object[] array = list.toArray();
		Long total = (Long) queryRunner.query(sqlFind, new ScalarHandler(),
				array);
		return total.intValue();
	}
}
