package cn.edu.aynu.rjxy.zsqd.domain;

import java.util.List;

public class PageBean {
	private int pageCode; // 当前页码，由jsp页面传回
	private int pageSize; // 每一页显示的记录数 为一个固定值
	private int total; // 总记录数
	private List rows; // 显示的数据集合

	public PageBean(int pageCode, int total, int pageSize) {
		super();
		this.pageCode = pageCode; // 当前是第几页
		this.total = total; // 从数据库种总共的记录数
		this.pageSize = pageSize; // 每一页显示的个数固定为 30
	}

	public PageBean() {

	}

	public int getPageCode() {
		return pageCode;
	}

	public void setPageCode(int pageCode) {
		this.pageCode = pageCode;
	}

	public int getPageSize() {
		return pageSize;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	public List getRows() {
		return rows;
	}

	public void setRows(List rows) {
		this.rows = rows;
	}
}
