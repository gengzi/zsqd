package cn.edu.aynu.rjxy.zsqd.web.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;

import com.mchange.lang.StringUtils;

import cn.edu.aynu.rjxy.zsqd.domain.Company;
import cn.edu.aynu.rjxy.zsqd.domain.PageBean;
import cn.edu.aynu.rjxy.zsqd.domain.Signin;
import cn.edu.aynu.rjxy.zsqd.domain.User;
import cn.edu.aynu.rjxy.zsqd.service.PageService;
import cn.edu.aynu.rjxy.zsqd.service.PageServiceImpl;
import cn.edu.aynu.rjxy.zsqd.service.SignService;
import cn.edu.aynu.rjxy.zsqd.service.SignServiceImpl;

import cn.itcast.servlet.BaseServlet;
import cn.itcast.utils.CommonUtils;

public class SignServlet extends BaseServlet {
	// 注入service
	private SignService signService = new SignServiceImpl();
	private PageService pageService = new PageServiceImpl();

	/**
	 * 插入签到信息
	 * 
	 * @param request
	 * @param response
	 * @throws ServletException
	 * @throws IOException
	 */
	public void signWork(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		Signin signin = CommonUtils.toBean(request.getParameterMap(),
				Signin.class);
		Company company = CommonUtils.toBean(request.getParameterMap(),
				Company.class);
		User user = CommonUtils.toBean(request.getParameterMap(), User.class);
		signin.setUser(user);
		signin.setCompany(company);
		// 将插入的公司信息保存到session域中
		boolean result = signService.insertSign(signin);
		if (result) {
			response.getOutputStream().write("success".getBytes("UTF-8"));
			return;
		}
		response.getOutputStream().write("failure".getBytes("UTF-8"));
		return;
	}

	/**
	 * 将公司gps添加到数据库
	 * 
	 * @param request
	 * @param response
	 * @throws ServletException
	 * @throws IOException
	 */
	public void addCompany(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		/*
		 * 1.获取表单信息 2.完善表单信息 3.把表单信息提交的数据库中 4.如果失败有异常抛出 5.如果成功直接返回
		 */
		Company company = (Company) request.getSession()
				.getAttribute("company");

		String cname = request.getParameter("cname");
		String caddress = request.getParameter("caddress");

		company.setCid(CommonUtils.uuid());
		company.setCname(cname);
		company.setCaddress(caddress);
		signService.addCompany(company);
	}

	/**
	 * 插入签到信息
	 * 
	 * @param request
	 * @param response
	 * @throws ServletException
	 * @throws IOException
	 */
	public void pageQuery(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// 1,获取从页面查询的数据
		// 当前页（当前是第几页）
		String page = request.getParameter("page");
		// 每页显示条数
		String rows = request.getParameter("rows");

		// 条件查询
		String uname = request.getParameter("uname");
		String stime = request.getParameter("stime");
		String begintime = request.getParameter("begintime");
		String endtime = request.getParameter("endtime");

		// String [] array ={uname,stime,begintime,endtime};
		// 封装数据
		try {
			PageBean pageBean = pageService.getPageBean(Integer.parseInt(page),
					Integer.parseInt(rows), uname, stime, begintime, endtime);
			// 使用Json 处理
			JSONObject jsonObject = JSONObject.fromObject(pageBean);
			String json = jsonObject.toString();

			response.setContentType("json/html;charset=UTF-8");
			response.getWriter().print(json);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
