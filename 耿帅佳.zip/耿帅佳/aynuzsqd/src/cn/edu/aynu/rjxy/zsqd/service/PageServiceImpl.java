package cn.edu.aynu.rjxy.zsqd.service;

import java.sql.SQLException;
import java.util.List;

import cn.edu.aynu.rjxy.zsqd.dao.PageDao;
import cn.edu.aynu.rjxy.zsqd.dao.PageDaoImpl;
import cn.edu.aynu.rjxy.zsqd.domain.PageBean;

public class PageServiceImpl implements PageService {

	private PageDao pageDao = new PageDaoImpl();

	@Override
	public PageBean getPageBean(int pageCode, int pageSize) throws Exception {
		// 总记录数
		int pageTotalRecord = pageDao.getPageTotalSignin();
		PageBean bean = new PageBean();
		bean.setTotal(pageTotalRecord); // 设置 total

		List listCustomerdatas = pageDao.getListSignin((pageCode - 1)
				* pageSize, pageSize);
		bean.setRows(listCustomerdatas);
		return bean;
	}

	@Override
	public PageBean getPageBean(int pageCode, int pageSize, String uname,
			String stime, String begintime, String endtime) throws Exception {
		int pageTotalRecord = pageDao.getPageTotalSignin(uname, stime,
				begintime, endtime);
		PageBean bean = new PageBean();
		bean.setTotal(pageTotalRecord);

		List listCustomerdatas = pageDao.getListSignin((pageCode - 1)
				* pageSize, pageSize, uname, stime, begintime, endtime);
		bean.setRows(listCustomerdatas);
		return bean;
	}

}
