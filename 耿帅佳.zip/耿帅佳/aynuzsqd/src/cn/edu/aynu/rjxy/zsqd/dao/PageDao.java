package cn.edu.aynu.rjxy.zsqd.dao;

import java.util.List;

public interface PageDao {

	public int getPageTotalSignin() throws Exception;

	public List getListSignin(int recoderStartIndex, int pagesize)
			throws Exception;

	public List getListSignin(int recoderStartIndex, int pageSize,
			String uname, String stime, String begintime, String endtime)
			throws Exception;

	public int getPageTotalSignin(String uname, String stime, String begintime,
			String endtime) throws Exception;
}
