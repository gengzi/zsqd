package cn.edu.aynu.rjxy.zsqd.dao;

import java.sql.SQLException;

import cn.edu.aynu.rjxy.zsqd.domain.User;

public interface UserDao {

	User findByUsername(String username)throws SQLException;

	/**  添加一个用户
	 * @param user
	 * @return
	 * @throws SQLException
	 */
	Integer addUser(User user)throws SQLException;

	void updatePassword(String username, String repassword) throws SQLException;

	Integer improveInformation(User user) throws SQLException;
	
	boolean isAdmin(String username) throws SQLException;

	boolean isExit(String username)throws SQLException;

	boolean isExitCid(String cid)throws SQLException;

	void delete(String uid)throws SQLException;

}
