package cn.edu.aynu.rjxy.zsqd.service;

public interface DepartmentService {
	
	

}
