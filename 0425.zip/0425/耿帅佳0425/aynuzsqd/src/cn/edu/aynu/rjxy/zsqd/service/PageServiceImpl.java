package cn.edu.aynu.rjxy.zsqd.service;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import cn.edu.aynu.rjxy.zsqd.dao.PageDao;
import cn.edu.aynu.rjxy.zsqd.dao.PageDaoImpl;
import cn.edu.aynu.rjxy.zsqd.domain.PageBean;
import cn.edu.aynu.rjxy.zsqd.domain.Signin;
import cn.edu.aynu.rjxy.zsqd.domain.User;

public class PageServiceImpl implements PageService {

	private PageDao pageDao = new PageDaoImpl();

	@Override
	public PageBean getPageBean(int pageCode, int pageSize) throws Exception {
		// 总记录数
		int pageTotalRecord = pageDao.getPageTotalSignin();
		PageBean bean = new PageBean();
		bean.setTotal(pageTotalRecord); // 设置 total

		List listCustomerdatas = pageDao.getListSignin((pageCode - 1)
				* pageSize, pageSize);
		bean.setRows(listCustomerdatas);
		return bean;
	}

	@Override
	public PageBean getPageBean(int pageCode, int pageSize, String uname,
			String stime, String begintime, String endtime,String cid) throws Exception {
		int pageTotalRecord = pageDao.getPageTotalSignin(uname, stime,
				begintime, endtime,cid);
		PageBean bean = new PageBean();
		bean.setTotal(pageTotalRecord);

		List listCustomerdatas = pageDao.getListSignin((pageCode - 1)
				* pageSize, pageSize, uname, stime, begintime, endtime,cid);
		bean.setRows(listCustomerdatas);
		return bean;
	}

	@Override
	public List<Signin> findAll() throws Exception {
		return pageDao.findAll();
	}

	@Override
	public PageBean getPageBean(int pageCode, int pageSize, String uname,
			String username, String cid) throws Exception {
		// 分页条件查询的 总条目数
		int pageTotalRecord = pageDao.getPageTotalStaff(uname, username, cid);
		PageBean bean = new PageBean();
		// 给PageBean 对象赋值
		bean.setTotal(pageTotalRecord);
		// 分页查询的数据
		List listCustomerdatas = pageDao.getListStaff(
				(pageCode - 1) * pageSize, pageSize, uname, username, cid);
		// 给PageBean 赋值
		bean.setRows(listCustomerdatas);
		return bean;

	}

	@Override
	public List<User> findAllStaff() throws Exception {
		return pageDao.findAllStaff();
	}

	@Override
	public PageBean getPageBeanDepartment(int parseInt, int parseInt2,
			String cid) throws Exception {
		int total = pageDao.getTotalDepartment(parseInt, parseInt2, cid);
		PageBean bean = new PageBean();
		bean.setTotal(total);
		List list = pageDao.getListDepartment(parseInt, parseInt2, cid);
		bean.setRows(list);
		return bean;
	}

	public PageBean getPageBeanCompany(int parseInt, int parseInt2,
			Map<String, Object> map) throws Exception {
		String cid = (String) map.get("cid");
		// 1
		int total = pageDao.getTotalCompany(parseInt, parseInt2, cid);
		PageBean bean = new PageBean();
		bean.setTotal(total);
		List list = pageDao.getListCompany(parseInt, parseInt2, cid);
		bean.setRows(list);
		return bean;
	}

}
