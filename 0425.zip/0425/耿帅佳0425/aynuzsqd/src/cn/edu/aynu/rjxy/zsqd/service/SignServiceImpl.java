package cn.edu.aynu.rjxy.zsqd.service;

import java.sql.SQLException;

import cn.edu.aynu.rjxy.zsqd.dao.SignDao;
import cn.edu.aynu.rjxy.zsqd.dao.SignDaoImpl;
import cn.edu.aynu.rjxy.zsqd.domain.Company;
import cn.edu.aynu.rjxy.zsqd.domain.Signin;

public class SignServiceImpl implements SignService {
	// 注入dao
	private SignDao signDao = new SignDaoImpl();

	public boolean insertSign(Signin signin) {
		try {
			boolean result = signDao.insertSign(signin);
			if (result) {// 表示插入成功
				return true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

	// 添加公司信息
	public void addCompany(Company company) {
		try {
			signDao.insertCompany(company);
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	@Override
	public void romove(String sid) {
		try {
			signDao.delete(sid);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void editSigninInfo(Signin signin) {
		try {
			signDao.edit(signin);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
