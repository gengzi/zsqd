package cn.edu.aynu.rjxy.zsqd.web.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;
import net.sf.json.JsonConfig;

import cn.edu.aynu.rjxy.zsqd.domain.Company;
import cn.edu.aynu.rjxy.zsqd.domain.PageBean;
import cn.edu.aynu.rjxy.zsqd.domain.User;
import cn.edu.aynu.rjxy.zsqd.service.DepartmentService;
import cn.edu.aynu.rjxy.zsqd.service.DepartmentServiceImpl;
import cn.edu.aynu.rjxy.zsqd.service.PageService;
import cn.edu.aynu.rjxy.zsqd.service.PageServiceImpl;
import cn.itcast.servlet.BaseServlet;
import cn.itcast.utils.CommonUtils;

public class DepartmentServlet  extends BaseServlet{

	private DepartmentService dapartmentService = new DepartmentServiceImpl();
	private PageService pageService = new PageServiceImpl();

	/**
	 * 查询部门的分页查询
	 * 
	 * @param request
	 * @param response
	 * @throws ServletException
	 * @throws IOException
	 */
	public void pageQuery(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		// 获取当前页
		String page = request.getParameter("page");
		// 获取一页显示条数
		String rows = request.getParameter("rows");
		//
		User user = (User) request.getSession().getAttribute("userLogin");
		String cid = user.getCid();
		try {
			PageBean pageBean = pageService.getPageBeanDepartment(
					Integer.parseInt(page), Integer.parseInt(rows), cid);
			JsonConfig config = new JsonConfig();
			config.setExcludes(new String[] {});
			JSONObject object = JSONObject.fromObject(pageBean, config);
			String json = object.toString();
			response.setContentType("json/html;charset=UTF-8");
			response.getWriter().print(json);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
