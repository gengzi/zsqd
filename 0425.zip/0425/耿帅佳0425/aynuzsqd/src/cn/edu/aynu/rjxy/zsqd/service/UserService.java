package cn.edu.aynu.rjxy.zsqd.service;

import cn.edu.aynu.rjxy.zsqd.domain.User;
import cn.edu.aynu.rjxy.zsqd.service.exception.UserException;

public interface UserService {

	/**
	 * 登陆
	 * 
	 * @param username
	 * @param password
	 * @return
	 * @throws UserException
	 */
	User login(String username, String password) throws UserException;

	/**
	 * 注册
	 * 
	 * @param user
	 * @throws UserException
	 */
	void regist(User user) throws UserException;

	// 用户信息完善服务
	Integer improve(User user);

	void updatePassword(String username, String password) throws UserException;

	boolean findUsername(String username) throws UserException;

	/**
	 * 判断cid 是否存在
	 * 
	 * @param cid
	 * @return
	 * @throws UserException
	 */
	boolean findCid(String cid) throws UserException;

	/**
	 * @param sid
	 */
	void romove(String uid);

}
