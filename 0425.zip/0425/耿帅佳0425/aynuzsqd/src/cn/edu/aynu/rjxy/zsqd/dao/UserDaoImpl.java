package cn.edu.aynu.rjxy.zsqd.dao;

import java.sql.SQLException;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;

import cn.edu.aynu.rjxy.zsqd.domain.Company;
import cn.edu.aynu.rjxy.zsqd.domain.User;
import cn.itcast.jdbc.JdbcUtils;

public class UserDaoImpl implements UserDao {
	private QueryRunner qr = new QueryRunner(JdbcUtils.getDataSource());

	/**
	 * 通过用户名查询用户
	 * 
	 * @throws SQLException
	 */
	public User findByUsername(String username) throws SQLException {
		try {
			String sql = "select uid,username,password,uname,cid,isadmin from t_user where username=?";
			return qr.query(sql, new BeanHandler<User>(User.class), username);
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}

	public Integer addUser(User user) throws SQLException {
		try {
			String sql = "insert into t_user(uid,username,password,cid,gender,uname,isadmin)values(?,?,?,?,?,?,?)";
			// select last_insert_id() lastId;返回之后修改字段的id
			return qr.update(sql, user.getUid(), user.getUsername(),
					user.getPassword(), user.getCid(), user.getGender(),
					user.getUname(), user.getIsadmin());
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}

	}

	public void updatePassword(String username, String repassword)
			throws SQLException {
		String sql = "update t_user set password=? where username=?";
		qr.update(sql, repassword, username);
	}

	public Integer improveInformation(User user) throws SQLException {
		String sql = "update t_user set uname=?,gender=?,cid=?,isadmin=? values(?,?,?,?,?) where uid=?";
		return qr.update(sql, user.getUname(), user.getGender(), user.getCid(),
				user.getIsadmin(), user.getUid());
	}

	/**
	 * 对用户是否为管理员进行判断
	 */
	public boolean isAdmin(String username) throws SQLException {
		String sql = "select username isadmin from t_user where username=?";
		User user = qr.query(sql, new BeanHandler<User>(User.class), username);
		if (user.getIsadmin()) {
			return true;
		} else {
			return false;
		}
	}

	public boolean isExit(String username) throws SQLException {
		String sql = "select username from t_user where username=?";
		User user = qr.query(sql, new BeanHandler<User>(User.class), username);
		if (!"".equals(user)) {// 表示用户名已经存在
			// TODO 此次有两个逻辑 ， 一个是为空 ， 一个不为空
			return false;
		}
		return true;// 表示用户名没有被注册
	}

	/**
	 * 判断公司是否存在
	 */
	public boolean isExitCid(String cid) throws SQLException {
		String sql = "select cid  from t_company where cid=?";
		Company company = qr.query(sql,
				new BeanHandler<Company>(Company.class), cid);
		if (company != null) {// 表示编号为cid的公司存在
			return true;
		} else {
			return false;
		}
	}

	@Override
	public void delete(String uid) throws SQLException {
		String sql ="delete from t_user where uid = ?";
		qr.update(sql,uid);
	}
}
