package cn.edu.aynu.rjxy.zsqd.domain;

import java.util.Arrays;

public class Company {
	private String id ; // uuid
	private String cid;//公司编号
	private String cname;//公司名称
	private String caddress ;// 公司文本地址
	private String addressgps1 ;// gps1
	private String addressgps2 ;// gps2
	private String addressgps3 ;// gps3
	private String addressgps4 ;// gps4
	private String addressgps5 ;// gps5
	
	private String astarttime ;  //上午上班时间
	private String aendtime ;    //上午 下班时间
	private String pstarttime ;  //下午 上班时间
	private String pendtime ;    //下午 下班时间
	
	public String getAstarttime() {
		return astarttime;
	}
	public void setAstarttime(String astarttime) {
		this.astarttime = astarttime;
	}
	public String getAendtime() {
		return aendtime;
	}
	public void setAendtime(String aendtime) {
		this.aendtime = aendtime;
	}
	public String getPstarttime() {
		return pstarttime;
	}
	public void setPstarttime(String pstarttime) {
		this.pstarttime = pstarttime;
	}
	public String getPendtime() {
		return pendtime;
	}
	public void setPendtime(String pendtime) {
		this.pendtime = pendtime;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getCid() {
		return cid;
	}
	public void setCid(String cid) {
		this.cid = cid;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getCaddress() {
		return caddress;
	}
	public void setCaddress(String caddress) {
		this.caddress = caddress;
	}
	public String getAddressgps1() {
		return addressgps1;
	}
	public void setAddressgps1(String addressgps1) {
		this.addressgps1 = addressgps1;
	}
	public String getAddressgps2() {
		return addressgps2;
	}
	public void setAddressgps2(String addressgps2) {
		this.addressgps2 = addressgps2;
	}
	public String getAddressgps3() {
		return addressgps3;
	}
	public void setAddressgps3(String addressgps3) {
		this.addressgps3 = addressgps3;
	}
	public String getAddressgps4() {
		return addressgps4;
	}
	public void setAddressgps4(String addressgps4) {
		this.addressgps4 = addressgps4;
	}
	public String getAddressgps5() {
		return addressgps5;
	}
	public void setAddressgps5(String addressgps5) {
		this.addressgps5 = addressgps5;
	}
	
}
