package cn.edu.aynu.rjxy.zsqd.dao;

import java.util.List;

import cn.edu.aynu.rjxy.zsqd.domain.Signin;
import cn.edu.aynu.rjxy.zsqd.domain.User;

public interface PageDao {

	public int getPageTotalSignin() throws Exception;

	public List getListSignin(int recoderStartIndex, int pagesize)
			throws Exception;

	/** 返回签到信息的分页查询的数据
 	 * @param recoderStartIndex
	 * @param pageSize
	 * @param uname
	 * @param stime
	 * @param begintime
	 * @param endtime
	 * @return  List
	 * @throws Exception
	 */
	public List getListSignin(int recoderStartIndex, int pageSize,
			String uname, String stime, String begintime, String endtime)
			throws Exception;

	/** 签到信息 的分页查询 的总记录数
	 * @param uname
	 * @param stime
	 * @param begintime
	 * @param endtime
	 * @return  int 类型的总记录数
	 * @throws Exception
	 */
	public int getPageTotalSignin(String uname, String stime, String begintime,
			String endtime) throws Exception;

	/**查询所有的签到信息
	 * @return
	 * @throws Exception
	 */
	public List<Signin> findAll() throws Exception ;

	/**查找所有的员工信息
	 * @return
	 */
	public List<User> findAllStaff() throws Exception ;

	/** 返回员工分页查询的 记录数
	 * @param uname
	 * @param username
	 * @return
	 */
	public int getPageTotalStaff(String uname, String username,String cid) throws Exception ;

	/** 返回员工分页查询的记录
	 * @param i
	 * @param pageSize
	 * @param uname
	 * @param username
	 * @return
	 */
	public List getListStaff(int i, int pageSize, String uname, String username,String cid)throws Exception ;
}
