package cn.edu.aynu.rjxy.zsqd.web.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.JSONException;
import org.json.JSONObject;

import cn.itcast.servlet.BaseServlet;
import cn.itcast.utils.CommonUtils;

import cn.edu.aynu.rjxy.zsqd.domain.User;
import cn.edu.aynu.rjxy.zsqd.service.UserService;
import cn.edu.aynu.rjxy.zsqd.service.UserServiceImpl;
import cn.edu.aynu.rjxy.zsqd.service.exception.UserException;

public class UserServlet extends BaseServlet {
	private UserService userService = new UserServiceImpl();

	/**
	 * pc端登录验证
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @throws ServletException
	 * @throws IOException
	 */
	public String login(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		/**
		 * 1.获取表单信息 2.将表单信息提交给service的login()方法进行验证
		 * 3.如果验证通过，将用户信息保存到session对象中，跳转到欢迎界面
		 * 4.如果验证未通过，保存错误信息到request域中，同时回显信息，再回到登录页面
		 */
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String checkcode = request.getParameter("checkcode");
		
		
		//获取验证码
		String key = (String) request.getSession().getAttribute("key");
		if (key != null&&key.equals(checkcode)) {
			try {
				User user = userService.login(username, password);
				HttpSession session = request.getSession();
				session.setAttribute("userLogin", user);// 将User对象保存到session域中
				return "/WEB-INF/pages/common/index.jsp";
			} catch (Exception e) {
				request.setAttribute("username", username);// 回显信息
				request.setAttribute("errorMsg", e.getMessage());// 保存错误信息到request域中
				return "/login.jsp";
			}
		}else {
			request.setAttribute("username", username);// 回显信息
			request.setAttribute("errorMsg", "验证码输入错误");// 保存错误信息到request域中
			return "/login.jsp";
		}
	}

	/**
	 * 手机端登录验证
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @throws ServletException
	 * @throws IOException
	 * @throws JSONException
	 */
	public void loginPhone(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException,
			JSONException {
		/**
		 * 1.获取表单信息 2.将表单信息提交给service的login()方法进行验证
		 * 3.如果验证通过，将用户信息保存到session对象中，跳转到欢迎界面
		 * 4.如果验证未通过，保存错误信息到request域中，同时回显信息，再回到登录页面
		 */
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		JSONObject newsJson = null;
		try {
			User user = userService.login(username, password);
			HttpSession session = request.getSession();
			session.setAttribute("userLogin", user);// 将User对象保存到session域中
			newsJson = new JSONObject();
			newsJson.put("uid", user.getUid());
			newsJson.put("username", user.getUsername());
			newsJson.put("password", user.getPassword());
			newsJson.put("cid", user.getCid());
			newsJson.put("uname", user.getUname());
			newsJson.put("isadmin", user.getIsadmin());
			newsJson.put("result", "success");
			System.out.println(user.getUid());
			response.getOutputStream().write(newsJson.toString().getBytes());
			// response.getWriter().print(newsJson.toString().getBytes());
			return;

		} catch (UserException e) {
			request.setAttribute("username", username);// 回显信息
			request.setAttribute("errorMsg", e.getMessage());// 保存错误信息到request域中
			newsJson = new JSONObject();
			newsJson.put("result", "failure");
			response.getOutputStream().write(newsJson.toString().getBytes());
			// response.getWriter().print(newsJson.toString().getBytes());
			return;
		}
	}

	/**
	 * 获取到手机端提交过来的地址判断用户是否存在
	 * 
	 * @param request
	 * @param response
	 * @throws ServletException
	 * @throws IOException
	 */
	public void isExistPhone(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String username = null;
		try {
			// 获取username字段
			username = request.getParameter("username");
			boolean result = userService.findUsername(username);
			JSONObject newsJson = null;
			if (result) {
				newsJson = new JSONObject();
				try {
					newsJson.put("username", username);
					newsJson.put("result", "success");
					response.getOutputStream().write(
							newsJson.toString().getBytes());
				} catch (JSONException e) {
					e.printStackTrace();
				}
				return;
			}
			response.getOutputStream().write("failure".getBytes("UTF-8"));
			return;
		} catch (UserException e) {
			response.getOutputStream().write("success".getBytes("UTF-8"));
			System.out.println(e.getMessage());
			request.setAttribute("username", username);// 回显信息
			request.setAttribute("errorMsg", e.getMessage());// 保存错误信息到request域中
			return;
		}

	}

	/**
	 * 判断公司是否存在
	 * 
	 * @param request
	 * @param response
	 * @throws ServletException
	 * @throws IOException
	 */
	public void isExistCid(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String cid = null;
		try {
			// 获取username字段
			cid = request.getParameter("cid");
			boolean result = userService.findCid(cid);
			if (result) {// 表示编号为cid的公司存在
				response.getOutputStream().write("success".getBytes());
				return;
			}
			response.getOutputStream().write("failure".getBytes());
			return;
		} catch (UserException e) {
			request.setAttribute("errorMsg", e.getMessage());// 保存错误信息到request域中
			return;
		}
	}
	
	
	/**
	 * 判断公司是否存在  web端
	 * 
	 * @param request
	 * @param response
	 * @throws ServletException
	 * @throws IOException
	 */
	public void isExistCidWeb(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String cid = null;
		try {
			// 获取username字段
			cid = request.getParameter("cid");
			boolean result = userService.findCid(cid);
			String flag ="false";
			if (result) {// 表示编号为cid的公司存在
				response.setContentType("text/html;charset=UTF-8");
				//相应ajax 请求
				flag= "true";
				response.getWriter().print(flag);
				return;
			}
			response.getWriter().print(flag);
			return;
		} catch (UserException e) {
			// 保存错误信息到request域中
			request.setAttribute("errorMsg", e.getMessage());
			return;
		}
	}

	/**
	 * 通过用户名和密码进行用户注册  手机端
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @throws ServletException
	 * @throws IOException
	 */
	public void regist(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		/**
		 * 1.获取地址栏中 2.将信息封装到map中，在将map中的数据封装到Bean中并返回
		 * 3.通过调用userservice的regist()提交数据 4.如果提交成功，反馈1 5.如果没有提交成功，回显信息并将错误信息反馈。
		 */

		User user = null;
		try {
			user = CommonUtils.toBean(request.getParameterMap(), User.class);
			user.setUid(CommonUtils.uuid());
			userService.regist(user);
			response.getOutputStream().write("success".getBytes());
			return;
		} catch (UserException e) {
			request.setAttribute("userRegist", user);
			response.getOutputStream().write("failure".getBytes());
			return;
		}
	}
	
	
	/**
	 * 通过用户名和密码进行用户注册
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @throws ServletException
	 * @throws IOException
	 */
	public void register(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		/**
		 * 1.获取地址栏中 2.将信息封装到map中，在将map中的数据封装到Bean中并返回
		 * 3.通过调用userservice的regist()提交数据 4.如果提交成功，反馈1 5.如果没有提交成功，回显信息并将错误信息反馈。
		 */

		User user = null;
		try {
			user = CommonUtils.toBean(request.getParameterMap(), User.class);
			user.setUid(CommonUtils.uuid());
			userService.regist(user);
			return;
		} catch (UserException e) {
			//注册失败
			request.setAttribute("registerError", e.getMessage());
			//转发到注册页面，显示错误提示
			request.getRequestDispatcher("/register.jsp").forward(request, response);
			return ;
		}
	}
	
	
	

	/**
	 * 完善用户信息
	 * 
	 * @param request
	 * @param response
	 * 
	 *            public void improvePhone(HttpServletRequest request,
	 *            HttpServletResponse response){ User user = null; try { user =
	 *            CommonUtils.toBean(request.getParameterMap(), User.class);
	 *            Integer m = userService.improve(user); if(m==1){
	 *            response.getOutputStream().write("success".getBytes());
	 *            return; }
	 *            response.getOutputStream().write("failure".getBytes());
	 *            return; } catch (IOException e) { // TODO Auto-generated catch
	 *            block e.printStackTrace(); } }
	 */
	/**
	 * 签到处理
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @throws ServletException
	 * @throws IOException
	 */
	public String signin(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		/*
		 * 1.通过request获取通过签到按钮提交数据 2.对签到提交的数据进行验证，一天最多能签到的次数上线，以及显示签到状态 3.
		 */
		return null;

	}

	/**
	 * 修改密码
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @throws ServletException
	 * @throws IOException
	 */
	public void updatePassword(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String username = null;
		try {
			username = request.getParameter("username");
			String password = request.getParameter("password");
			// String repassword=request.getParameter("resetPassword");
			userService.updatePassword(username, password);
			response.getOutputStream().write("success".getBytes());
			return;
		} catch (UserException e) {
			request.setAttribute("errorMsg", e.getMessage());
			response.getOutputStream().write("failure".getBytes());
			return;
		}
	}
	
	



}
