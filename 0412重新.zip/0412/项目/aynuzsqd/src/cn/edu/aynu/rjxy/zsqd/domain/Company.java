package cn.edu.aynu.rjxy.zsqd.domain;

import java.util.Arrays;

public class Company {
	private String cid;//公司编号
	private String cname;//公司名称
	private String caddress ;// 公司文本地址
	private String addressgps1 ;// gps1
	private String addressgps2 ;// gps2
	private String addressgps3 ;// gps3
	private String addressgps4 ;// gps4
	private String addressgps5 ;// gps5
	public String getCid() {
		return cid;
	}
	public void setCid(String cid) {
		this.cid = cid;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getCaddress() {
		return caddress;
	}
	public void setCaddress(String caddress) {
		this.caddress = caddress;
	}
	public String getAddressgps1() {
		return addressgps1;
	}
	public void setAddressgps1(String addressgps1) {
		this.addressgps1 = addressgps1;
	}
	public String getAddressgps2() {
		return addressgps2;
	}
	public void setAddressgps2(String addressgps2) {
		this.addressgps2 = addressgps2;
	}
	public String getAddressgps3() {
		return addressgps3;
	}
	public void setAddressgps3(String addressgps3) {
		this.addressgps3 = addressgps3;
	}
	public String getAddressgps4() {
		return addressgps4;
	}
	public void setAddressgps4(String addressgps4) {
		this.addressgps4 = addressgps4;
	}
	public String getAddressgps5() {
		return addressgps5;
	}
	public void setAddressgps5(String addressgps5) {
		this.addressgps5 = addressgps5;
	}
	@Override
	public String toString() {
		return "Company [cid=" + cid + ", cname=" + cname + ", caddress="
				+ caddress + ", addressgps1=" + addressgps1 + ", addressgps2="
				+ addressgps2 + ", addressgps3=" + addressgps3
				+ ", addressgps4=" + addressgps4 + ", addressgps5="
				+ addressgps5 + "]";
	}
	
	
	
	
	
	
	
}
