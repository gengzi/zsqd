package cn.edu.aynu.rjxy.zsqd.dao;

import java.sql.SQLException;
import org.apache.commons.dbutils.QueryRunner;
import cn.edu.aynu.rjxy.zsqd.domain.Signin;
import cn.itcast.jdbc.JdbcUtils;


public class SignDaoImpl implements SignDao {
	//注入数据源
	private QueryRunner qr = new  QueryRunner(JdbcUtils.getDataSource()); 
	public boolean insertSign(Signin signin) throws SQLException {
		String sql="insert into t_signin(sid,uid,cid,stime,saddress,saddressgps,isauto,issuccess) values(?,?,?,?,?,?,?,?)";
		int i=qr.update(sql, signin.getSid(),signin.getUser().getUid(),signin.getCompany().getCid(),signin.getStime(),signin.getSaddress(),signin.getSaddressgps(),signin.isIsauto(),signin.isIssuccess());
		if(i==1){
			return true;
		}
		return false;
	}
}
