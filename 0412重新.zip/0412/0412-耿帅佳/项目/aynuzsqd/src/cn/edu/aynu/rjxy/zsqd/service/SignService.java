package cn.edu.aynu.rjxy.zsqd.service;

import cn.edu.aynu.rjxy.zsqd.domain.Signin;


public interface SignService {
    //插入签到信息
	boolean insertSign(Signin signin);

}
