package cn.edu.aynu.rjxy.zsqd.web.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.edu.aynu.rjxy.zsqd.domain.Company;
import cn.edu.aynu.rjxy.zsqd.domain.Signin;
import cn.edu.aynu.rjxy.zsqd.domain.User;
import cn.edu.aynu.rjxy.zsqd.service.SignService;
import cn.edu.aynu.rjxy.zsqd.service.SignServiceImpl;

import cn.itcast.servlet.BaseServlet;
import cn.itcast.utils.CommonUtils;

public class SignServlet extends BaseServlet {
	// 注入service
	private SignService signService = new SignServiceImpl();

	public void signWork(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		Signin signin = CommonUtils.toBean(request.getParameterMap(),
				Signin.class);
		Company company = CommonUtils.toBean(request.getParameterMap(),
				Company.class);
		User user = CommonUtils.toBean(request.getParameterMap(), User.class);
		signin.setUser(user);
		signin.setCompany(company);
		System.out.println(signin);
		boolean result = signService.insertSign(signin);
		if (result) {
			response.getOutputStream().write("success".getBytes("UTF-8"));
			return;
		}
		response.getOutputStream().write("failure".getBytes("UTF-8"));
		return;
	}

}
