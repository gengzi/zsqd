package cn.edu.aynu.rjxy.zsqd.service;

import java.sql.SQLException;

import cn.edu.aynu.rjxy.zsqd.dao.SignDao;
import cn.edu.aynu.rjxy.zsqd.dao.SignDaoImpl;
import cn.edu.aynu.rjxy.zsqd.domain.Signin;



public class SignServiceImpl implements SignService {
	//注入dao
	private SignDao signDao = new SignDaoImpl();

	public boolean insertSign(Signin signin) {
		try {
			boolean result = signDao.insertSign(signin);
			if(result){//表示插入成功
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}

}
