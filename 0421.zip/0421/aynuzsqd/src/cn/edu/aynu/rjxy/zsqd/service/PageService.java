package cn.edu.aynu.rjxy.zsqd.service;

import java.sql.SQLException;
import java.util.List;

import cn.edu.aynu.rjxy.zsqd.domain.PageBean;
import cn.edu.aynu.rjxy.zsqd.domain.Signin;

public interface PageService {

	public PageBean getPageBean(int pageCode, int pageSize) throws Exception;

	public PageBean getPageBean(int pageCode, int pageSize, String uname,
			String stime, String begintime, String endtime) throws Exception;

	public List<Signin> findAll()throws Exception;

}
