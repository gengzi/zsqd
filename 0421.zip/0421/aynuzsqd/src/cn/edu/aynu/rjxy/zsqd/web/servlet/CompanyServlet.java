package cn.edu.aynu.rjxy.zsqd.web.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.edu.aynu.rjxy.zsqd.domain.Company;
import cn.edu.aynu.rjxy.zsqd.domain.User;
import cn.edu.aynu.rjxy.zsqd.service.CompanyService;
import cn.edu.aynu.rjxy.zsqd.service.CompanyServiceImpl;
import cn.itcast.servlet.BaseServlet;
import cn.itcast.utils.CommonUtils;

public class CompanyServlet extends BaseServlet {
	private CompanyService companyService  = new CompanyServiceImpl();

	/**
	 * 插入公司gps
	 * @param request
	 * @param response
	 * @throws ServletException
	 * @throws IOException
	 */
	public String insertCompanyGps(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		/*
		 * 1.获取表单gps信息
		 * 2.获取session域中的Company对象
		 *   判断Company是否为空，如果为空直接返回到注册公司页面
		 * 3.如果不为空将gps信息保存到添加到数据库中
		 * 4.如果添加失败抛出异常
		 * 5.如果添加成功结束
		 */
		Company companyForm = CommonUtils.toBean(request.getParameterMap(), Company.class);
		//获取session中的Company对象
		User user = (User) request.getSession().getAttribute("userLogin");
		if(user ==null){
			request.setAttribute("msg", "您还没有登陆，请登陆！");
			return "/login.jsp";
		}
		companyForm.setCid(user.getCid());
		Company companyBycid = companyService.findByCId(user.getCid());
		companyForm.setCaddress(companyBycid.getCaddress());
		companyForm.setCname(companyBycid.getCname());
		companyForm.setId(CommonUtils.uuid());
		companyService.insertCompanyGps(companyForm);
		return "/WEB-INF/pages/company/map.jsp";
	}

	/**  注册时，保存公司信息（初始化）
	 * @param company
	 */
	public void save(Company company) {
		
		companyService.initCompanyInfo(company);
	}
}
