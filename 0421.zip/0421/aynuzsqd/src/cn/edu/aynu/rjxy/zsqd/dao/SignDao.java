package cn.edu.aynu.rjxy.zsqd.dao;

import java.sql.SQLException;

import cn.edu.aynu.rjxy.zsqd.domain.Company;
import cn.edu.aynu.rjxy.zsqd.domain.Signin;

public interface SignDao {
    //插入员信息
	boolean insertSign(Signin signin) throws SQLException;
    //插入公司信息
	void insertCompany(Company company) throws SQLException;

}
