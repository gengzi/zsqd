package cn.edu.aynu.rjxy.zsqd.web.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import net.sf.json.JSONObject;

import com.mchange.lang.StringUtils;

import cn.edu.aynu.rjxy.zsqd.domain.Company;
import cn.edu.aynu.rjxy.zsqd.domain.PageBean;
import cn.edu.aynu.rjxy.zsqd.domain.Signin;
import cn.edu.aynu.rjxy.zsqd.domain.User;
import cn.edu.aynu.rjxy.zsqd.service.PageService;
import cn.edu.aynu.rjxy.zsqd.service.PageServiceImpl;
import cn.edu.aynu.rjxy.zsqd.service.SignService;
import cn.edu.aynu.rjxy.zsqd.service.SignServiceImpl;
import cn.edu.aynu.rjxy.zsqd.utils.FileUtils;

import cn.itcast.servlet.BaseServlet;
import cn.itcast.utils.CommonUtils;

public class SignServlet extends BaseServlet {
	// 注入service
	private SignService signService = new SignServiceImpl();
	private PageService pageService = new PageServiceImpl();

	/**
	 * 插入签到信息
	 * 
	 * @param request
	 * @param response
	 * @throws ServletException
	 * @throws IOException
	 */
	public void signWork(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		Signin signin = CommonUtils.toBean(request.getParameterMap(),
				Signin.class);
		Company company = CommonUtils.toBean(request.getParameterMap(),
				Company.class);
		User user = CommonUtils.toBean(request.getParameterMap(), User.class);
		signin.setUser(user);
		signin.setCompany(company);
		// 将插入的公司信息保存到session域中
		boolean result = signService.insertSign(signin);
		if (result) {
			response.getOutputStream().write("success".getBytes("UTF-8"));
			return;
		}
		response.getOutputStream().write("failure".getBytes("UTF-8"));
		return;
	}

	/**
	 * 将公司gps添加到数据库
	 * 
	 * @param request
	 * @param response
	 * @throws ServletException
	 * @throws IOException
	 */
	public void addCompany(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		/*
		 * 1.获取表单信息 2.完善表单信息 3.把表单信息提交的数据库中 4.如果失败有异常抛出 5.如果成功直接返回
		 */
		Company company = (Company) request.getSession()
				.getAttribute("company");

		String cname = request.getParameter("cname");
		String caddress = request.getParameter("caddress");

		company.setCid(CommonUtils.uuid());
		company.setCname(cname);
		company.setCaddress(caddress);
		signService.addCompany(company);
	}

	/**
	 * 插入签到信息
	 * 
	 * @param request
	 * @param response
	 * @throws ServletException
	 * @throws IOException
	 */
	public void pageQuery(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// 1,获取从页面查询的数据
		// 当前页（当前是第几页）
		String page = request.getParameter("page");
		// 每页显示条数
		String rows = request.getParameter("rows");

		// 条件查询
		String uname = request.getParameter("uname");
		String stime = request.getParameter("stime");
		String begintime = request.getParameter("begintime");
		String endtime = request.getParameter("endtime");

		// String [] array ={uname,stime,begintime,endtime};
		// 封装数据
		try {
			PageBean pageBean = pageService.getPageBean(Integer.parseInt(page),
					Integer.parseInt(rows), uname, stime, begintime, endtime);
			// 使用Json 处理
			JSONObject jsonObject = JSONObject.fromObject(pageBean);
			String json = jsonObject.toString();

			response.setContentType("json/html;charset=UTF-8");
			response.getWriter().print(json);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/**
	 * 导出execal
	 * 
	 * @param request
	 * @param response
	 * @throws Exception 
	 */
	public void export(HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		//查询数据
		List<Signin> list = pageService.findAll();
		//创建excel
		HSSFWorkbook hssfWorkbook  = new HSSFWorkbook();
		//创建一个 sheet
		HSSFSheet sheet = hssfWorkbook.createSheet();
		//创建第一行
		HSSFRow row = sheet.createRow(0);
		// 
		row.createCell(0).setCellValue("签到时间");
		row.createCell(1).setCellValue("姓名");
		row.createCell(2).setCellValue("签到地址");
		row.createCell(3).setCellValue("是否签到成功");
		row.createCell(4).setCellValue("是否自动签到");
		
		//根据数据设置 
		
		for (Signin signin : list) {
			HSSFRow rowSignin = sheet.createRow(sheet.getLastRowNum()+1);
			rowSignin.createCell(0).setCellValue(signin.getStime());
			rowSignin.createCell(1).setCellValue(signin.getUname());
			rowSignin.createCell(2).setCellValue(signin.getSaddress());
			boolean issuccess = signin.isIssuccess();
			if (issuccess) {
				rowSignin.createCell(3).setCellValue("签到成功");
			}else {
				rowSignin.createCell(3).setCellValue("签到失败");
			}
			boolean isauto = signin.isIsauto();
			if (isauto) {
				rowSignin.createCell(4).setCellValue("自动签到");
			}else {
				rowSignin.createCell(4).setCellValue("手动签到");
			}
		}
		
		// 设置文件
		
		String filename ="签到信息.xls";
		
		 String agent = request.getHeader("User-Agent");
         filename = FileUtils.encodeDownloadFilename(filename, agent);
         //一个流两个头
         ServletOutputStream out = response.getOutputStream();
         String contentType = this.getServletContext().getMimeType(filename);
         response.setContentType(contentType);
         response.setHeader("content-disposition", "attchment;filename="+filename);
         hssfWorkbook.write(out);
	}
}
