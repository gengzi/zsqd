/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50548
Source Host           : localhost:3306
Source Database       : zsqd

Target Server Type    : MYSQL
Target Server Version : 50548
File Encoding         : 65001

Date: 2017-04-21 22:46:38
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for t_company
-- ----------------------------
DROP TABLE IF EXISTS `t_company`;
CREATE TABLE `t_company` (
  `id` varchar(64) NOT NULL,
  `cid` varchar(30) NOT NULL,
  `cname` varchar(60) NOT NULL,
  `caddress` text,
  `addressgps5` varchar(32) DEFAULT NULL,
  `addressgps4` varchar(32) DEFAULT NULL,
  `addressgps3` varchar(32) DEFAULT NULL,
  `addressgps2` varchar(32) DEFAULT NULL,
  `addressgps1` varchar(32) DEFAULT NULL,
  `astarttime` varchar(20) DEFAULT NULL,
  `aendtime` varchar(20) DEFAULT NULL,
  `pstarttime` varchar(20) DEFAULT NULL,
  `pendtime` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_company
-- ----------------------------
INSERT INTO `t_company` VALUES ('0B9BDC2C151B4060B899C7044C2C27E8', '17839166574', '安阳聚信集团', '安阳', '', '', '', '', '', null, null, null, null);
INSERT INTO `t_company` VALUES ('281D48C0E5904F8DAD701718F794F4F2', '17839166574', '安阳聚信集团', '安阳', '', '114.40146,36.098645', '114.401784,36.103019', '114.395783,36.098266', '114.396214,36.103311', null, null, null, null);
INSERT INTO `t_company` VALUES ('7F837ACE24464174AB6C4DCD43DA1DD2', '17839166574', '安阳聚信集团', '安阳', '114.390537,36.107976', '114.390573,36.107976', '114.392621,36.102144', '114.384249,36.101619', '114.383566,36.106606', null, null, null, null);
INSERT INTO `t_company` VALUES ('A87E142D702C4CE389A4B3CB52493DED', '17839166574', '安阳聚信集团', '安阳', '114.397688,36.108297', '114.402574,36.10544', '114.401245,36.098937', '114.39104,36.098645', '114.392118,36.102436', null, null, null, null);
INSERT INTO `t_company` VALUES ('ACEAA57F44764B03A68FF8D86D757DDA', '17839166574', '安阳聚信集团', '安阳', '', '114.40146,36.098645', '114.401784,36.103019', '114.395783,36.098266', '114.396214,36.103311', null, null, null, null);
INSERT INTO `t_company` VALUES ('C500C12D92DA4E33A3E80B5DD60EC96A', '17839166574', '安阳聚信集团', '安阳', '', '', '', '', '', null, null, null, null);
INSERT INTO `t_company` VALUES ('EDADB92363314538941FE8F0B55DC6E5', '17839166574', '安阳聚信集团', '安阳', '', '114.400311,36.107889', '114.403616,36.104856', '114.390681,36.10194', '114.394238,36.107306', null, null, null, null);

-- ----------------------------
-- Table structure for t_department
-- ----------------------------
DROP TABLE IF EXISTS `t_department`;
CREATE TABLE `t_department` (
  `did` varchar(64) DEFAULT NULL,
  `dname` varchar(64) DEFAULT NULL,
  `cid` varchar(64) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_department
-- ----------------------------
INSERT INTO `t_department` VALUES ('fdsfdsfdsfds', '开发部', '17839166574');

-- ----------------------------
-- Table structure for t_signin
-- ----------------------------
DROP TABLE IF EXISTS `t_signin`;
CREATE TABLE `t_signin` (
  `sid` varchar(64) NOT NULL,
  `uid` varchar(64) DEFAULT NULL,
  `cid` varchar(64) DEFAULT NULL,
  `stime` varchar(64) DEFAULT NULL,
  `saddress` varchar(64) DEFAULT NULL,
  `isauto` varchar(64) DEFAULT NULL,
  `saddressgps` varchar(255) DEFAULT NULL,
  `issuccess` varchar(255) DEFAULT NULL,
  `uname` varchar(255) DEFAULT NULL,
  `isenable` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`sid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_signin
-- ----------------------------
INSERT INTO `t_signin` VALUES ('023af10529444bbb977e6463f8bca402', '809814D2C13C476887BE63EC8DDC6E7B', '10001', '2017-04-10 21:14:38', '中国河南省安阳市文峰区文澜路', 'false', '36.064903|114.373442', 'true', '耿帅佳', '1');
INSERT INTO `t_signin` VALUES ('e06fa0c6fb464ea3b788ffe185a03a49', 'e06fa0c6fb464ea3b788ffe185a03a42', '10001', '2017-03-16 08:56:00', '中国河南省安阳市文峰区黄河大道', 'false', '36.068184|114.377183', 'false', '贾谭克', '1');
INSERT INTO `t_signin` VALUES ('e06fa0c6fb464ea3b788ffe185a03a49111', '321321312', '10001', '2017-09-22', '河南', 'false', '32313', 'flase', '耿', '1');

-- ----------------------------
-- Table structure for t_user
-- ----------------------------
DROP TABLE IF EXISTS `t_user`;
CREATE TABLE `t_user` (
  `uid` varchar(64) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `uname` varchar(20) DEFAULT NULL,
  `gender` varchar(4) DEFAULT NULL,
  `cid` varchar(30) DEFAULT NULL,
  `isadmin` varchar(10) DEFAULT NULL,
  `isenable` varchar(255) DEFAULT NULL,
  `did` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_user
-- ----------------------------
INSERT INTO `t_user` VALUES ('117F38E07C054E91B56560CEABB3A82F', '17839166574', '1164014750', '耿帅佳', '男', '17839166574', '1', '1', null);
